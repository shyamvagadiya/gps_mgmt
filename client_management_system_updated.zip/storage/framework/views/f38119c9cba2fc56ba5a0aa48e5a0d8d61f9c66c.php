<nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <li class="nav-item nav-profile">
              <a href="#" class="nav-link">
                <div class="profile-image">
                  <img class="img-xs rounded-circle" src="<?php echo e(asset('assets/images/faces-clipart/pic-1.png')); ?>" alt="profile image">
                  <div class="dot-indicator bg-success"></div>
                </div>
                <div class="text-wrapper">
                  <p class="profile-name"><?php echo e(Auth::user()->name); ?></p>
                </div>
              </a>
            </li>
            
            
            
          </ul>
        </nav><?php /**PATH C:\xampp\htdocs\client_management_system_updated\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>