<table class="table table-responsive" id="myTable">
                      <thead>
                        <tr>
                          <th>Customer No</th>
                          <th>Company</th>
                          <th>Name</th>
                          <th>City</th>
                          <th>State</th>
                          <th>Mobile No</th>
                          <th>Type</th>
                          <th>User ID</th>
                          <th>Application</th>
                          <th>Vehicle No</th>

                          <th>Device Type</th>
                          <th>SIM No</th>
                          <th>IMEI NO</th>

                          <th>Created Date</th>
                          <th>Expiry Date</th>
                          <th>Warranty</th>

                          

                          <th>Vehicle Status</th>
                          <th>Payment Details</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                            <?php if(count($clients) > 0): ?>
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(isset($client->client->customer_no) ? $client->client->customer_no : "-"); ?></td>
                                        <td><?php echo e(isset($client->client->company) ? $client->client->company : "-"); ?></td>
                                        <td><?php echo e(isset($client->client->customer_name) ? $client->client->customer_name : "-"); ?></td>
                                        <td><?php echo e(isset($client->client->city) ? $client->client->city : "-"); ?></td>
                                        <td><?php echo e(isset($client->client->state) ? $client->client->state : "-"); ?></td>
                                        <td><?php echo e(isset($client->client->mobile_no) ? $client->client->mobile_no : "-"); ?></td>
                                        <td><?php echo e(isset($client->type->name) ? $client->type->name : "-"); ?></td>
                                        <td><?php echo e($client->user_id); ?></td>
                                        <td><?php echo e(isset($client->application->name) ? $client->application->name : "-"); ?></td>
                                        <td><?php echo e($client->vehicle_no); ?></td>
                                        <td><?php echo e($client->device_type); ?></td>
                                        <td><?php echo e($client->sim_no); ?></td>
                                        <td><?php echo e($client->imei_no); ?></td>
                                        <td><?php echo e($client->created_at); ?></td>
                                        <td><?php echo e($client->expiry_date); ?></td>
                                        <td><?php echo e($client->warranty); ?></td>


                                        <td><?php echo e($client->vehicle_status); ?></td>
                                        <td><?php echo e($client->payment_details); ?></td>
                                        <td>
                                            <?php if(Auth::user()->is_admin == 1): ?>
                                                <button class="btn btn-info updatePayment" data-id="<?php echo e($client->id); ?>">Update Payment</button>
                                            <?php else: ?> 
                                                <button disabled class="btn btn-info" data-id="<?php echo e($client->id); ?>">Update Payment</button>
                                            <?php endif; ?>

                                            <a class="btn btn-primary" href="<?php echo e(route('edit.vehicle_status',$client->id)); ?>">Edit Status</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            <?php endif; ?>
                      </tbody>
                    </table><?php /**PATH C:\xampp\htdocs\client_management_system_updated\resources\views/vehicle/dyanamicTable.blade.php ENDPATH**/ ?>