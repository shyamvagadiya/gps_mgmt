<table class="table " id="myTable">
                      <thead>
                        <tr>
                          <th>Customer No</th>
                          <th>Company</th>
                          <th>Name</th>
                          <th>City</th>
                          <th>State</th>
                          <th>Mobile No</th>
                          <th>Alternate Mobile No</th>
                          <th>Created Date</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                            <?php if(count($clients) > 0): ?>
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($client->customer_no); ?></td>
                                        <td><?php echo e(isset($client->company) ? $client->company : "-"); ?></td>
                                        <td><?php echo e($client->customer_name); ?></td>
                                        <td><?php echo e($client->city); ?></td>
                                        <td><?php echo e($client->state); ?></td>
                                        <td><?php echo e($client->mobile_no); ?></td>
                                        <td><?php echo e($client->alt_mobile_no); ?></td>
                                        <td><?php echo e($client->created_at); ?></td>
                                        <td><a href="<?php echo e(route('client.edit',$client->id)); ?>" class="btn btn-info">Edit</a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            <?php endif; ?>
                      </tbody>
                    </table><?php /**PATH C:\xampp\htdocs\client_management_system_updated\resources\views/client/dyanamicTable.blade.php ENDPATH**/ ?>